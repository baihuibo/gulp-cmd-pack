import {toStr} from './libs/util.js';

import '../styles/index.css'
console.log('main2', toStr);

//////////////////////
