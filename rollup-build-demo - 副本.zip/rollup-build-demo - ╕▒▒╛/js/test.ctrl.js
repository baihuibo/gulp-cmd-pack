window.init = function () {
    // angular.module('app').controller('TestCtrl', ['$scope111', function ($scope) {
    //     console.log($scope);
    // }])
    //
    // angular.module('app').controller('Test2Ctrl', class {
    //     constructor($scope) {
    //     }
    //
    //     fn() {
    //     }
    // })
    //
    // angular.module('app').service('Ctrl', function ($http) {
    //     console.log('http', $http)
    // })
    //
    // angular.module('app').directive('Ctrl', function ($http) {
    //     return {
    //         link: function () {
    //
    //         }
    //     }
    // });

    angular.module('app').provider('myService', function () {
        this.$get = function ($http) {
            console.log($http);
        }
    })
    angular.module('app').provider('myService2', function () {
        return {
            version: '123',
            $get: function ($http) {
                console.log($http, this.version);
            }
        }
    })
    var obj = {
        config(){}
    };

    obj.config(function (obj) {

    })

    // var app = angular.module('app', []);
    //
    // app.component('MyComp', {
    //     template: 'asdf',
    //     controller: ['http', function ($http) {
    //         console.log('http', $http)
    //     }]
    // })
    // app.component('MyComp', {
    //     template: 'asdf',
    //     controller: class {
    //         constructor($http) {
    //             console.log('http', $http)
    //         }
    //     }
    // });
    // app.run(function ($rootScope) {
    //     console.log($rootScope);
    // })
}