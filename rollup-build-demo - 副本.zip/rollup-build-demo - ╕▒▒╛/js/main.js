import * as util from './libs/util.js';
import '../styles/index.css';
import './test.ctrl';
//
import('./other.js').then(function (mod) {
    console.log(mod);
})
console.log('main1222', util.toStr);
//////////////
