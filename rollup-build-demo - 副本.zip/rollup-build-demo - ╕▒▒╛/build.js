const rollup = require('rollup');
const pluginJson = require('@rollup/plugin-json');
const pluginImage = require('@rollup/plugin-image');
const {writeFileSync, readFileSync} = require('fs');
const fs = require('fs-extra');
const path = require('path');
const {JSDOM} = require('jsdom');
const crequire = require('crequire');
const {minify: htmlMinify} = require('html-minifier');
const glob = require('glob');
const {terser} = require('rollup-plugin-terser');
const {minify: terserMinify} = require('terser');
const styles = require('rollup-plugin-styles');
const walk = require('acorn-walk');
const MagicString = require('magic-string');


const CWD = process.cwd();

const pages = glob.sync('./pages/**/*.html');

const inputOptions = {
    input: ['./index.html', ...pages],
    plugins: [
        customHtmlPlugin(),
        styles(),
        pluginJson(),
        assetResolverPlugin(/\.(png|jpe?g|gif|svg|ico|webp)(\?.*)?$/i),
        assetResolverPlugin(/\.(mp4|webm|ogg|mp3|wav|flac|aac)(\?.*)?$/i),
        assetResolverPlugin(/\.(woff2?|eot|ttf|otf)(\?.*)?$/i),
        // terser(),
        ngAnnotate(),
    ]
};
const outputOptions = {
    format: 'es',
    entryFileNames: '[name]-[hash].js',
    assetFileNames: 'assets/[name]-[hash][extname]',
};

async function build() {
    const bundle = await rollup.rollup(inputOptions);

    const {output} = await bundle.generate(outputOptions);

    fs.emptyDirSync('dist');

    for (const chunkOrAsset of output) {
        if (chunkOrAsset.type === 'asset') {
            // For assets, this contains
            // {
            //   fileName: string,              // the asset file name
            //   source: string | Uint8Array    // the asset source
            //   type: 'asset'                  // signifies that this is an asset
            // }
            const name = 'dist/' + chunkOrAsset.fileName;
            fs.ensureDirSync(path.dirname(name));
            writeFileSync(name, chunkOrAsset.source);
        } else {
            // For chunks, this contains
            // {
            //   code: string,                  // the generated JS code
            //   dynamicImports: string[],      // external modules imported dynamically by the chunk
            //   exports: string[],             // exported variable names
            //   facadeModuleId: string | null, // the id of a module that this chunk corresponds to
            //   fileName: string,              // the chunk file name
            //   imports: string[],             // external modules imported statically by the chunk
            //   isDynamicEntry: boolean,       // is this chunk a dynamic entry point
            //   isEntry: boolean,              // is this chunk a static entry point
            //   map: string | null,            // sourcemaps if present
            //   modules: {                     // information about the modules in this chunk
            //     [id: string]: {
            //       renderedExports: string[]; // exported variable names that were included
            //       removedExports: string[];  // exported variable names that were removed
            //       renderedLength: number;    // the length of the remaining code in this module
            //       originalLength: number;    // the original length of the code in this module
            //     };
            //   },
            //   name: string                   // the name of this chunk as used in naming patterns
            //   type: 'chunk',                 // signifies that this is a chunk
            // }
            // console.log(chunkOrAsset.fileName);
            let name = 'dist/';
            // console.log(chunkOrAsset);
            if (chunkOrAsset.fileName.endsWith('.js')) {
                name += 'js/' + chunkOrAsset.fileName;
            } else if (chunkOrAsset.fileName.endsWith('.html')) {
                name += chunkOrAsset.facadeModuleId.replace(CWD, '');
            }
            name = path.normalize(name);
            fs.ensureDirSync(path.dirname(name));
            writeFileSync(name, chunkOrAsset.code);
        }
    }
}

build();

function customHtmlPlugin() {
    const htmlMap = new Map();
    const props = ['poster', 'src', 'href'];

    return {
        name: 'build:html',
        async load(id) {
            if (id && id.endsWith('.html')) {
                const cache = htmlMap.get(id) || {
                    scripts: [],
                    inlineScripts: [],
                    assets: [],
                };
                const dom = new JSDOM(readFileSync(id, 'utf-8'));
                cache.dom = dom;

                // 资源处理
                const assets = dom.window.document.querySelectorAll('script,link,video,img,source');

                let scriptContent = '';
                const dir = path.dirname(id);

                for (const asset of assets) {
                    if (asset.localName === 'script') {
                        if (asset.src) {
                            const uri = asset.src;
                            const referenceId = this.emitFile({
                                type: 'chunk',
                                importer: id,
                                id: path.resolve(dir, uri),
                            });
                            cache.scripts.push({
                                asset, referenceId,
                                baseName: path.basename(uri)
                            });
                            scriptContent += `import "${uri}";\n`;
                        } else {
                            // import 静态导入
                            const imports = crequire(asset.textContent, true);

                            // 动态导入
                            const reg = /import\(['"](.*?)['"]\)/g;
                            let match;
                            while (match = reg.exec(asset.textContent)) {
                                imports.push({string: match[0], path: match[1], index: match.index})
                            }

                            const inlineReps = [];
                            for (let i = 0; i < imports.length; i++) {
                                const refSource = imports[i];
                                const referenceId = this.emitFile({
                                    type: 'chunk',
                                    id: path.resolve(dir, refSource.path),
                                });
                                inlineReps.push({referenceId, refSource});
                            }
                            cache.inlineScripts.push({asset, inlineReps})
                        }

                    } else if (asset.localName !== 'script') {
                        let prop, uri;
                        for (let i = 0; i < props.length; i++) {
                            if ((uri = asset[props[i]])) {
                                prop = props[i];
                                break;
                            }
                        }
                        if (uri) {
                            const referenceId = this.emitFile({
                                type: 'asset',
                                name: path.basename(uri),
                                source: readFileSync(path.resolve(dir, uri))
                            });
                            cache.assets.push({asset, referenceId, prop});
                        }
                    }
                }
                htmlMap.set(id, cache);
                if (!scriptContent.trim()) {
                    scriptContent = 'export default {}';
                }
                return scriptContent;
            }
        },
        async renderChunk(code, chunk) {
            const {facadeModuleId: id} = chunk;

            if (id && id.endsWith('.html')) {
                if (chunk.isEntry) {
                    chunk.fileName = path.basename(id.replace(CWD, ''));
                } else {
                    chunk.fileName = chunk.fileName.replace(/js$/, 'html');
                }
                const cache = htmlMap.get(id);
                cache.scripts.forEach(({asset, referenceId, baseName}) => {
                    asset.src = '/js/' + this.getFileName(referenceId);
                });
                for (const {asset, inlineReps} of cache.inlineScripts) {
                    inlineReps.forEach(({referenceId, refSource}) => {
                        const refUri = refSource.string.replace(refSource.path, '/js/' + this.getFileName(referenceId));
                        asset.textContent = asset.textContent.replace(refSource.string, refUri);
                    });
                    asset.textContent = terserMinify(asset.textContent).code;
                }
                cache.assets.forEach(({asset, referenceId, prop}) => {
                    asset[prop] = '/' + this.getFileName(referenceId);
                });
            }
        },
        async generateBundle(options, bundle) {
            for (const [fileId, chunk] of Object.entries(bundle)) {
                const {fileName, facadeModuleId: id} = chunk;
                if (fileName && fileName.endsWith('.html')) {
                    chunk.code = htmlMap.get(id).dom.serialize();
                }
            }
        }
    }
}

function assetResolverPlugin(extname) {
    return ({
        resolveId(source, importer) {
            if (extname.test(source)) {
                return path.resolve(path.dirname(importer), source);
            }
        },
        load(id) {
            if (extname.test(id)) {
                const referenceId = this.emitFile({
                    type: 'asset',
                    name: path.basename(id),
                    source: readFileSync(id)
                });
                return `export default import.meta.ROLLUP_FILE_URL_${referenceId};`;
            }
        }
    });
}

function ngAnnotate() {
    return {
        transform(code, id) {
            if (id.endsWith('.js') && code.includes('angular')) {
                const magicString = new MagicString(code)
                const ast = this.parse(code);

                const props = ['controller', 'service', 'factory', 'config', 'filter', 'directive', 'run'];
                walk.simple(ast, {
                    CallExpression(node) {
                        try {
                            if (node.callee && node.callee.property) {
                                if (props.includes(node.callee.property.name)) {
                                    inject(node.arguments[node.arguments.length - 1]);
                                } else if (node.callee.property.name === 'component') {
                                    const expression = node.arguments[node.arguments.length - 1];
                                    Property(expression, 'controller');
                                } else if (node.callee.property.name === 'provider') {
                                    const expression = node.arguments[node.arguments.length - 1];
                                    walk.simple(expression, {
                                        AssignmentExpression(node) {
                                            if (node.left.property.name === '$get') {
                                                inject(node.right);
                                            }
                                        },
                                        ReturnStatement(node) {
                                            Property(node, '$get');
                                        }
                                    })
                                }
                            }
                        } catch (e) {
                        }
                    }
                })

                return {code: magicString.toString(), map: magicString.generateMap()};

                function Property(ast, key) {
                    walk.simple(ast, {
                        Property(node) {
                            if (node.key.name === key) {
                                inject(node.value);
                            }
                        }
                    })
                }

                function inject(node) {
                    if (node.type === 'FunctionExpression') {
                        const params = getParams(node.params)
                        magicString.appendLeft(node.start, `[${params},`);
                        magicString.appendRight(node.end, ']');
                    } else if (node.type === 'ClassExpression') {
                        node.body.body.forEach(definition => {
                            if (definition.type === 'MethodDefinition' && definition.kind === 'constructor') {
                                const params = getParams(definition.value.params)
                                magicString.appendLeft(definition.start, `static $inject = [${params}];\n`);
                            }
                        })
                    }
                }

                function getParams(params) {
                    return params.map(param => JSON.stringify(param.name)).join(',');
                }
            }
        }
    }
}
